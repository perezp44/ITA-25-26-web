#- script para seguir las slides_05A_data-munging

#- The pipe
#- pp. 7 -----------------------------------------------------------------------

head(iris, n = 4)         #- forma habitual de llamar/usar la función head()

iris %>% head(. , n = 4)  #- usando el operador pipe


#- pp. 8 -----------------------------------------------------------------------

#- Estas 3 expresiones también son equivalentes, hacen exactamente lo mismo:

head(iris, n = 4)         #- forma habitual de llamar/usar la función head()

iris %>% head(. , n = 4)  #- usando el operador pipe (con el punto actuando como placeholder)

iris %>% head(n = 4)      #- usando el operador pipe (SIN el punto)


#- Qué hacen la siguienten expresiones?
  
4 %>% head(iris, .)

4 %>% head(iris)


#- Intenta descubrir/entender que hace la siguiente expresión:
  
letters %>% paste0( "-----" ,  .  ,  "!!!" ) %>% toupper



#- pp. 12 ----------------------------------------------------------------------
#- Tidy data … ejemplo I

df_1 <- data.frame(
  year  = c("2014", "2015", "2016"),  
  Pedro = c(100, 500, 200), 
  Carla = c(400, 600, 250), 
  María = c(200, 700, 900)  )

DT::datatable(df_1)



#- pp. 13 ----------------------------------------------------------------------
#- Tidy data … ejemplo II

df_2 <- data.frame(names = c("Pedro", "Carla", "María"), 
                   W_2014 = c(100, 400, 200), 
                   W_2015 = c(500, 600, 700),
                   W_2016 = c(200, 250, 900)   )

knitr::kable(df_2)



#- pp. 14 ----------------------------------------------------------------------
#- Tidy data … ejemplo III

df_3 <- data.frame(
  names =rep(c("Pedro", "Carla", "María"), times = 3),  
  year = rep(c("2014", "2015", "2016"), each = 3),
  salario = c(100, 400, 200, 500, 600, 700, 200, 250,900) )

gt::gt(df_3)



#- pp. 17 ----------------------------------------------------------------------
#- Tarea: convierte “df_wide” a formato LARGO

df_wide <- data.frame(students = c("Pedro", "Carla", "María"), 
                      w_2014 = c(100, 400, 200), 
                      w_2015 = c(500, 600, 700),
                      w_2016 = c(200, 250, 900) )


#- Solution
#- la función pivot_longer() transforma los datos de formato ancho(wide) a formato largo(long)
library(tidyverse)

df_long <- df_wide %>% 
  tidyr::pivot_longer(cols = 2:4)

gt::gt(df_long)




#- Extended solution
#- la función pivot_longer() transforma los datos de formato ancho(wide) a formato largo(long)
df_long <- df_wide %>% 
  tidyr::pivot_longer(cols = 2:4, 
                      names_to = "periodo", 
                      values_to = "salario")
gt::gt(df_long)




#- pp 19 -----------------------------------------------------------------------
#- Tarea: convierte “df_long” a formato ANCHO
#- una columna para cada año

#- Solution

df_wide2 <- df_long %>% 
  tidyr::pivot_wider(values_from = salario,  
                     names_from = periodo)

gt::gt(df_wide2)


#- pp 20 -----------------------------------------------------------------------
#- Tarea: convierte OTRA VEZ “df_long” a formato ANCHO
#- ahora una columna para cada persona

df_wide2 <- df_long %>%
  tidyr::pivot_wider(values_from = salario,
                     names_from = students)

gt::gt(df_wide2)


#- pp 23 -----------------------------------------------------------------------
#- Tarea: Utilizando tidyr::separate()

#- Separa la columna personajes en dos columnas: nombre y apellido
df <- data.frame( personajes = c("Pedro Navaja", "Bob Dylan", "Peter Pan"), 
                  year  = c(1978, 1941, 1904) )

gt::gt(df)

df_1 <- df %>% 
  tidyr::separate(col = personajes, 
                  into = c("nombre", "apellido"), 
                  sep = " ")

gt::gt(df_1)


#- pp 24 (*) -------------------------------------------------------------------
#- Tarea: Utilizando tidyr::unite()
df_1 <- df %>% 
  tidyr::separate(col = personajes, 
                  into = c("nombre", "apellido"), 
                  sep = " ")

gt::gt(df_2)

#- puedes arreglar el error??
#- script para seguir las slides_05C: Data-munging(III)

library(tidyverse)

#- trabajaremos con datos del pkg gapminder
gapminder <- gapminder::gapminder


#- CONTAR (observaciones) ------------------------------------------------------

#- pp. 6 -----------------------------------------------------------------------
#- 1. Usando mutate() con n()

#- fíjate q con mutate() se mantienen todas las filas y todas las columnas
aa <- gapminder %>% mutate(NN = n())  

nrow(aa)  #- se mantienen las 1704 observaciones


#- 1. mutate() mantiene el nº de filas originales (1704)
bb <- head(aa, n = 3)
gt::gt(bb)



#- 2. Usando summarise() con n()
#- fíjate q  summarise() solo devuelve una fila y una columna
aa <- gapminder %>% summarise(NN = n())

#- 2. summarise() devuelve una fila (por grupo)
gt::gt(aa)


#- 3, usando count()
aa <- gapminder %>% count()

#- 3. count() devuelve una fila (por grupo)
gt::gt(aa)


#- pp. 7 -----------------------------------------------------------------------
#- seguimos contando
#- Pero ahora contamos el nº de observaciones de distintos grupos

# fíjate q  summarise() devuelve una fila por cada grupo
# una fila por cada continente
aa <- gapminder %>%
  group_by(continent) %>% summarise(NN = n())

gt::gt(aa)

aa <- gapminder %>% count(continent)

gt::gt(aa)


#- pp. 8 -----------------------------------------------------------------------
#- aun seguimos contando

# fíjate q hay 60 grupos (5 continentes x 12 periodos)
# por lo que devuelve 60 filas, una por grupo

aa <- gapminder %>%
  group_by(continent, year) %>% summarise(NN = n())


aa <- gapminder %>% count(year, continent)

bb <- head(aa, n = 14)
gt::gt(bb)


#- #- pp. 9 --------------------------------------------------------------------
#- Extensión: n() versus nrow()

#- como agrupamos por año y continente, saldrán 60 grupos (12 x 5)

#- con n()
#- como agrupamos por año y continente, saldrán 60 grupos (12 x 5)
aa <- gapminder %>%
  group_by(continent, year) %>% 
  summarise(NN = n()) %>% 
  ungroup()

aa %>% slice(1, 2, 12, 13) %>% 
  gt::gt() %>% 
  gtExtras::gt_theme_guardian()


#- con nrow()
#- como agrupamos por año y continente, saldrán 60 grupos (12 x 5)

#- con nrow()
bb <- gapminder %>% 
  group_by(continent, year) %>% 
  summarise(NN = nrow(.)) %>% 
  ungroup()


bb %>% slice(1, 2, 12, 13) %>% 
  gt::gt() %>% 
  gtExtras::gt_theme_dark()


#- observaciones DISTINTAS -----------------------------------------------------

#- pp. 11 ----------------------------------------------------------------------
#-  ver/obtener observaciones DISTINTAS con distinct()

# gapminder tiene 1.704 filas: ninguna repetida
aa <- gapminder %>% distinct()

# gapminder no tiene filas repetidas
nrow(aa) == nrow(gapminder)

# en gapminder hay 5 valores distintos para los continentes
aa <- gapminder %>% distinct(continent)

# efectivamente 5 continentes
nrow(aa)


# en gapminder hay 5 valores distintos para los continentes y 12 para los periodos
aa <- gapminder %>% distinct(continent, year)

# efectivamente 60:  5 continentes x 12 periodos
nrow(aa)


#- pp. 12 ----------------------------------------------------------------------
#- CONTAR observaciones DISTINTAS con n_distinct()

# nº de países distintos en cada continente
aa <- gapminder %>%
  group_by(continent) %>%
  summarise(NN = n_distinct(country))

gt::gt(aa)


# nº de países distintos en cada continente
aa <- gapminder %>%
  group_by(year, continent) %>%
  summarise(NN = n_distinct(country)) %>% 
  ungroup()


gt::gt(head(aa, n = 7))


#- calculando ESTADISTICOS: máximo, mínimo, media, …… --------------------------
#- pp. 14 ----------------------------------------------------------------------


aa <- gapminder %>%
  summarise(maximo = max(lifeExp, na.rm = TRUE),
            minimo = min(lifeExp, na.rm = TRUE),
            media = mean(lifeExp, na.rm = TRUE) )

gt::gt(aa)

#- calcular estadísticos por continente
aa <- gapminder %>% group_by(continent) %>%
  summarise(maximo = max(lifeExp, na.rm = TRUE),
            minimo = min(lifeExp, na.rm = TRUE),
            media = mean(lifeExp, na.rm = TRUE) )

aa %>% gt::gt()


#- pp. 15 ----------------------------------------------------------------------
#- ESTADISTICOS para Europa año a año ...

#- calcular estadísticos por CONTINENTE Y AÑO
#- calcular estadísticos por CONTINENTE Y AÑO
aa <- gapminder %>% 
  group_by(continent, year) %>%
  summarise(maximo = max(lifeExp, na.rm = TRUE),
            minimo = min(lifeExp, na.rm = TRUE), 
            mean = mean(lifeExp, na.rm = TRUE) ) %>% 
  ungroup() %>%
  filter(continent == "Europe")



aa %>% gt::gt() %>% gt::fmt_number(3:5, decimals = 2)


#- pp. 16 (**) -----------------------------------------------------------------
#- en la slide anterior, al calcular la esperanza de vida media por continente,
#- estábamos promediando países con diferente población 🫣

#- Tarea:  hemos de calcular la media, pero ponderada por la población (pop)

#- Solución
aa <- gapminder %>%
  group_by(continent, year) %>%
  summarise(mean = mean(lifeExp, na.rm = TRUE),
            mean_w = weighted.mean(lifeExp, w = pop, na.rm = TRUE)) %>%
  ungroup() %>%
  filter(year == 2007)


aa %>% gt::gt() %>% 
  gt::fmt_number(3:4, decimals = 2)




#- pp. 18 ----------------------------------------------------------------------
#- calculando CRECIMIENTOS
#- calcular el crecimiento de la esperanza de vida, de un periodo a otro, en España
aa <- gapminder %>% 
  select(country, year, lifeExp) %>%
  group_by(country) %>%
  arrange(year) %>%
  mutate(crecimiento =  lifeExp - lag(lifeExp)) %>%
  mutate(crecimiento2 = lifeExp - lag(lifeExp, default = first(lifeExp))) %>%
  ungroup() %>%
  filter(country == "Spain")


gt::gt(aa) %>%
  gt::fmt_number(3:5, decimals = 2)




#- pp. 19 ----------------------------------------------------------------------
#- calculando CRECIMIENTOS ACUMULADOS

aa <- gapminder %>% 
  select(country, year, lifeExp) %>%   
  group_by(country) %>%
  arrange(year) %>%
  mutate(crec_1 = lifeExp - lag(lifeExp)) %>%
  mutate(crec_2 = lifeExp - lag(lifeExp, default = first(lifeExp))) %>%
  mutate(crec_acu_1 = cumsum(crec_1)) %>%
  mutate(crec_acu_2 = cumsum(crec_2)) %>%
  mutate(crec_acu_3 = lifeExp - first(lifeExp)) %>%
  ungroup() %>%
  filter(country == "Spain") 


gt::gt(aa) %>%
  gt::fmt_number(3:8, decimals = 2)




#- pp. 22 ----------------------------------------------------------------------
#- calculando PORCENTAJES (con R à la tidyverse)


#- Calcular % de población de cada continente
aa <- gapminder %>% 
  group_by(continent, year) %>%
  summarise(pob_continent = sum(pop, na.rm = TRUE)) %>% ungroup() %>%
  group_by(year) %>%
  mutate(pob_mundo = sum(pob_continent),
         pob_percent = pob_continent/pob_mundo * 100) %>%
  ungroup()



bb <- aa %>% filter(year %in% c(1952, 2007))



gt::gt(head(bb, n = 15)) %>%
  gt::fmt_number(pob_percent, decimals = 2)





#- pp. 23 ----------------------------------------------------------------------
#- Extensión: tabla con la importancia (en términos de población) de cada continente en el tiempo

#- Ahora quiero hacer la tabla presentable: he de pasarla a formato ancho

bb <- aa %>% 
  select(continent, year, pob_mundo, pob_percent) %>%
  tidyr::pivot_wider(names_from = continent, 
                     values_from = pob_percent) 


bb <- aa %>% 
  select(continent, year, pob_mundo, pob_percent) %>%
  tidyr::pivot_wider(names_from = continent, 
                     values_from = pob_percent) 





#- pp. 25 ----------------------------------------------------------------------
#- calculando RANKINGs


#- Calcular el ranking de España en cuanto a Esperanza de vida

aa <- gapminder %>% 
  select(country, year, lifeExp) %>%
  group_by(year) %>%
  mutate(rank_1 = row_number(desc(lifeExp))) %>%
  mutate(rank_2 = min_rank(desc(lifeExp)) ) %>% 
  #- también puedo calcular el ranking a mano
  arrange(desc(lifeExp)) %>%
  mutate(rank_mio = 1:n())  %>%
  ungroup() 



aa %>% 
  filter(country == "Spain") %>% 
  gt::gt() %>% 
  gt::fmt_number(3:5, decimals = 0)




#- pp. 27 ----------------------------------------------------------------------
#- ifelse(): ejecuta “algo” de manera condicional


aa <- gapminder %>% 
  select(-pop) %>% 
  mutate(X1 = ifelse(lifeExp > 70, "longevo", "no longevo")) %>% 
  mutate(X2 = ifelse(gdpPercap > 10000, "rico", "pobre")) %>% 
  mutate(X3 = ifelse(lifeExp > 70 & gdpPercap > 10000, 
                     "longevo y rico", 
                     "no longevo y/o pobre")) %>% 
  mutate(X4 = ifelse(continent == "Europe", "europeo", "no europeo")) 


#- el resultado es:
aa %>% filter(country %in% c("Spain", "Angola")) %>% 
  filter(year %in% c(1952, 2007)) %>% 
  gt::gt() %>% 
  gt::opt_stylize(style = 3) %>% 
  gt::cols_align(align = "center")


#- pp. 28 ----------------------------------------------------------------------
#- case_when(): es una generalización de ifelse()

aa <- gapminder %>%
  group_by(continent, year)  %>%
  mutate(media_lifeExp = mean(lifeExp)) %>% 
  mutate(media_gdpPercap = mean(gdpPercap)) %>% 
  mutate(GOOD_or_BAD = case_when( 
    lifeExp > mean(lifeExp) & gdpPercap > mean(gdpPercap)  ~ "good",
    lifeExp < mean(lifeExp) & gdpPercap < mean(gdpPercap)  ~ "bad" ,
    lifeExp < mean(lifeExp) | gdpPercap < mean(gdpPercap)  ~ "medium",
    .default = "otros casos"  ) )


#- el resultado es:
aa %>% ungroup() %>% filter(country == "Spain") %>% select(-pop) %>%
  gt::gt() %>% 
  gt::fmt_number(4:7, sep_mark = ".",   dec_mark = ",", decimals = 2) %>% 
  gt::opt_stylize(style = 2) %>% 
  gt::cols_align(align = "center")






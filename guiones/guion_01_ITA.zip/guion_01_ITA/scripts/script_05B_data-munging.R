#- script para seguir las slides_05B: ata-munging
library(tidyverse)

#- pp. 9 -----------------------------------------------------------------------
#- trabajaremos con datos del pkg gapminder

gapminder <- gapminder::gapminder


#- pp. 10 ----------------------------------------------------------------------
#- select() se utiliza para seleccionar variables


#- Seleccionar variables por nombre
aa <- gapminder %>% select(year, lifeExp)

#- Eliminar variables por nombre
aa <- gapminder %>% select(-year, -lifeExp)

#- Seleccionar variables por posición
aa <- gapminder %>% select(1:3, 5)

#- Eliminar variables por posición
aa <- gapminder %>% select(-c(1:3, 5))


#- pp. 11 ----------------------------------------------------------------------
#- A veces queremos reordenar las columnas/variables

#- Podemos hacerlo relocate()
aa <- gapminder %>% dplyr::relocate(country, .after = lifeExp)

aa <- gapminder %>% dplyr::relocate(country, .before = lifeExp)


#- pp. 12 ----------------------------------------------------------------------
#- A veces queremos renombrar las columnas


#- Podemos hacerlo rename()
gapminder %>% rename(life_exp = lifeExp)


#- la funció names() de R-base es útil
aa <- gapminder

names(aa)


#- pp. 13 ----------------------------------------------------------------------
#- A veces queremos CREAR nuevas columnas


aa <- gapminder %>% mutate(GDP = pop * gdpPercap)

#- Extensión
aa <- gapminder %>% mutate(GDP = pop * gdpPercap, .after = pop)


#- pp. 14 ----------------------------------------------------------------------
#- filter(): permite seleccionar filas



gapminder <- gapminder::gapminder  #- cargamos los datos

#- Observaciones de España (country == "Spain")
aa <- gapminder %>% filter(country == "Spain")

#- filas con valores de "lifeExp" < 29
aa <- gapminder %>% filter(lifeExp < 29)

#- filas con valores de "lifeExp" entre [29, 32]
aa <- gapminder %>% filter(lifeExp >=  29 &  lifeExp <= 32)
aa <- gapminder %>% filter(between(lifeExp, 29, 32))

#- observaciones de países de África con lifeExp > 32
aa <- gapminder %>% filter(lifeExp > 72 &  continent == "Africa")

#- observaciones de países de África o Asia con lifeExp > 32
aa <- gapminder %>% filter(lifeExp > 72 &  continent %in% c("Africa", "Asia") )
aa <- gapminder %>% filter(lifeExp > 72 & (continent == "Africa" | continent == "Asia") )


#- pp. 15 ----------------------------------------------------------------------
#- slice() es una variante de filter() que selecciona filas por posición


#- selecciona las observaciones de la décima a la quinceava
aa <- gapminder %>% slice(c(10:15))

#- selecciona las 4 primeras observaciones, de la 41 a a la 43, y las 4 últimas
aa <- gapminder %>%
  slice( c(1:4, 41:43, (n()-3):n() ) )



#- pp. 16 ----------------------------------------------------------------------
#- slice_max() y slice_min(): seleccionan filas con valor máximo (o mínimo) de una variable


#- selecciona las 3 filas con mayor valor de lifeExp
aa <- gapminder %>% slice_max(lifeExp, n = 3)

#- selecciona las 4 filas con MENOR valor de pop
aa <- gapminder %>% slice_min(pop, n = 4)

#- observaciones en el primer décil en cuanto a esperanza de vida, 10% con menor esperanza de vida
aa <- gapminder %>% slice_min(lifeExp, prop = 0.1)

#- 1% de observaciones con mayor población. Imagino que estarán China e India
aa <- gapminder %>% slice_max(pop, prop = 0.01)


#- pp. 17 ----------------------------------------------------------------------
#- variantes de slice()
#- slice_sample(): permite obtener una muestra aleatoria de los datos


#- selecciona (aleatoriamente) 100 filas de los datos
aa <- gapminder %>% slice_sample(n = 100)

#- selecciona (aleatoriamente) un 5% de los datos
aa <- gapminder %>% slice_sample(prop = 0.05)



#- pp. 18 ----------------------------------------------------------------------
#- arrange(): permite reordenar las filas de un df


#- ordena las filas de MENOR a mayor según los valores de la v. lifeExp
aa <- gapminder %>% arrange(lifeExp)

#- ordena las filas de MAYOR a menor según los valores de la v. lifeExp
aa <- gapminder %>% arrange(desc(lifeExp))

#- ordena las filas de MENOR a mayor según los valores de la v. lifeExp.
#- Si hubiesen empates se resuelve con la variable "pop"
aa <- gapminder %>% arrange(lifeExp, pop)



#- pp. 19 ----------------------------------------------------------------------
#- summarize() para “resumir” variables

aa <- gapminder %>% summarise(maximo = max(pop))      #- el valor máximo de la variable "pop"

aa <- gapminder %>% summarise(NN = n())               #- el número de observaciones

aa <- gapminder %>% summarise(media = mean(lifeExp))  #- la media de la variable "lifeExp"

aa <- gapminder %>% summarise(desviacion_tipica = sd(lifeExp))  #- os lo explicarán en Estadística



#- pp. 20 ----------------------------------------------------------------------

#- summarize(): “resumimos” dos variables
#- retornará 2 valores: las medias de "lifeExp" y "gdpPercap"
aa <- gapminder %>% summarise(mean(lifeExp), mean(gdpPercap))

#- summarize(): hacemos 2 resúmenes de una variable
#- retornará 2 valores: la media y máximo de la v. "lifeExp"
aa <- gapminder %>% summarise(mean(lifeExp), max(lifeExp))



#- pp. 21 ----------------------------------------------------------------------
#- group_by(): con está función ya se puede ver la potencia de dplyr

# calculamos el nº de observaciones en el df
aa <- gapminder %>% summarise(NN = n())

gt::gt(aa)


# ahora queremos calcular el nº de observaciones de cada continente
# cogemos df y lo (des)agrupamos por grupos definidos por la variable "continent"
# o sea, habrá 5 grupos (5 continentes)
# después con summarise() calcularemos el nº de observaciones en cada grupo;
# es decir, nos retornará un df con una fila por cada continente
# con el nº de observaciones de cada continente

bb <- gapminder %>% group_by(continent) %>% summarise(NN = n())

gt::gt(bb)



#- COMBINANDO tablas (joining df’s) --------------------------------------------



#- pp. 24 ----------------------------------------------------------------------
#- mutating joins: un ejemplo
#- En el ejemplo usaremos estos 2 df’s:



df1 <- tibble(id = 1:3, x = paste0("x", 1:3))
df2 <- tibble(id = 1:4, y = paste0("y", 1:4)) %>% slice(-3)

df1
df2

#- pp. 25 ----------------------------------------------------------------------

df_inner <- inner_join(df1, df2)    #- inner_join() only includes observations that match in df1 and df2


df_full_join <- full_join(df1, df2)     #- full_join() includes all observations from df1 and df2


df_left_join <- left_join(df1, df2)   #- left_join()  includes all observations in df1






#- EXTENSIONES -----------------------------------------------------------------

#- pp. 27 ----------------------------------------------------------------------

#- Ejemplo de uso: select() junto a la función where() [🌶🌶🌶🌶]

#- seleccionar sólo las variables numéricas
aa <- gapminder %>% select(is.numeric)        #- funciona, pero ...

aa <- gapminder %>% select(where(is.numeric)) #- es "preferible" esta segunda expresión


#- Si quisiseramos seleccionar las variables que NO son numéricas haríamos:
  
aa <- gapminder %>% select(!where(is.numeric)) 


#- pp. 28 ----------------------------------------------------------------------

#- más ejemplos de across() y where()

#- media de todas (everything()) las variables. 
#- Devuelve 2 warnings porque las 2 primeras son textuales. No se puede calcular la media de continent y country
gapminder %>% summarise(across(everything(), mean) )


#- Ahora calculamos la media de la tercera a la sexta variable:
gapminder %>% summarise(across(3:6, mean) )



#- pp. 29 ----------------------------------------------------------------------

#- across() y where() con summarise() 😱
gapminder %>% summarise(across(where(is.numeric), mean))

#- script para seguir las slides_04 (importar y exportar datos)

#- pp. 5------------------------------------------------------------------------
#- Tarea: descargar un fichero de datos con R



#- Solución (I)
my_url <- "https://raw.githubusercontent.com/perezp44/archivos_download/refs/heads/master/plazas_turisticas.csv"


download.file(my_url, "plazas_turisticas.csv")

download.file(url = my_url,                               
              destfile = "plazas_turisticas.csv")          


#- Solución (II)
my_url <- "https://raw.githubusercontent.com/perezp44/archivos_download/refs/heads/master/plazas_turisticas.csv"

fs::dir_create("pruebas")

download.file(my_url, "./pruebas/plazas_turisticas.csv")

download.file(url = my_url,
              destfile = "./pruebas/plazas_turisticas.csv")


#- Extended solution

my_url <- "https://raw.githubusercontent.com/perezp44/archivos_download/refs/heads/master/plazas_turisticas.csv"  

my_ruta <- "./pruebas/plazas_turisticas.csv"


curl::curl_download(url = my_url,
                    destfile = my_ruta)       


curl::curl_download(url = my_url,
                    destfile = my_ruta)



#- pp. 7 -----------------------------------------------------------------------
#- intenta entender el siguiente chunk de código

#- cuando iniciamos R se cargan automáticamente un grupo de paquetes (R-base)
print(.packages()) #- [🌶]imprimimos los nombres de los "currently attached packages"

#- en uno de esos paquetes hay un conjunto de datos llamado "iris"
iris          #- llamamos a "iris"
find("iris")  #- [🌶] ¿donde está iris?
str(iris)     #- qué es iris?


my_iris <- iris  #- "hacemos una copia" de iris en el Global
find("my_iris")  #- ¿donde está my_iris?

iris <- c(2, 4)    #- creamos un vector llamado iris
find("iris")       #- ¿donde está ahora iris?



rm(list = ls())   # borramos el Global



#- pp. 8 -----------------------------------------------------------------------
#- Tarea: usar unos datos de un paquete

#- Solución

#- install.packages("refugees")
library(refugees)

my_flows <- flows



#- Extended solution

my_flows_2 <- refugees::flows



rm(list = ls())   # borramos el Global



#- pp. 13 ----------------------------------------------------------------------
#- Tarea: importar a R datos que tenemos guardados en nuestro ordenador

#- Solución

my_ruta <- "./pruebas/plazas_turisticas.csv"

df <- rio::import(my_ruta)


#- Extended solution

my_ruta <- "./pruebas/plazas_turisticas.csv"

df <- rio::import(file = my_ruta)


rm(list = ls())   # borramos el Global


#- pp. 17 ----------------------------------------------------------------------
#- Tarea: exportar unos datos de R a un fichero


#- Solución

df <- iris

rio::export(df, "iris.csv")

rio::export(x = df,
            file = "iris.csv")


#- Tarea II: Por favor, guarda/graba iris.csv en la subcarpeta “pruebas” del Rproject
#- Solución (II)

rio::export(df, "./pruebas/iris.csv")

rio::export(x = df,
            file = "./pruebas/iris.csv")


#- pp. 18 ----------------------------------------------------------------------
#- Práctica: importar/exportar datos

#- antes borramos ./pruebas/
fs::dir_delete("pruebas")
fs::dir_create("pruebas")


#- Solución (está vez has de hacerlo tú)

# 1. Descargando los datos

#- en esta url hay un fichero de datos en formato .csv
my_url <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv"

curl::curl_download(url = my_url,
                    destfile =  "./pruebas/iris.csv")

# 2. Importando los datos
my_ruta <- "./pruebas/iris.csv"

iris <- rio::import(my_ruta)

# 3. Exportando los datos
rio::export(x = iris, file = "./pruebas/iris.xlsx")

rio::export(x = iris, file = "./pruebas/iris.rds")




rm(list = ls())   # borramos el Global


#- pp. 20 ----------------------------------------------------------------------
#- Eurostat:

# install.packages("eurostat")
library(eurostat)

#- importamos los datos de la tabla "cult_emp_sex": "Cultural employment by sex"
df <- eurostat::get_eurostat("cult_emp_sex")



#- pp. 21 ----------------------------------------------------------------------
#- Practica: importar datos de Eurostat

library(eurostat)

#- podemos buscar un  "tema" con la f. search_eurostat()
my_tema <- "employment"

aa <- eurostat::search_eurostat(pattern = my_tema, type = "all")

#- elegimos un dataset; por ejemplo "hlth_silc_17"
my_table <- "hlth_silc_17"

#- da información sobre la Base de datos que estas buscando
eurostat::label_eurostat_tables(my_table)

#-  importamos los datos de "my_table" con get_eurostat()
df <- eurostat::get_eurostat(my_table, time_format = "raw", keepFlags = TRUE )

#- pedimos los descriptores/labels de las series
df_l <- eurostat::label_eurostat(df)



#- pp. 22 ----------------------------------------------------------------------
#- El paquete quantmod

library(quantmod)  #- install.packages("quantmod")

#- For stocks and shares, the yahoo source is used.
facebook  <- getSymbols(Symbols = 'F', src = 'yahoo', auto.assign = FALSE)
barChart(facebook)

#- For currencies and metals, the oanda source is used.
tc_euro_dolar <- getSymbols(Symbols = 'EUR/USD', src = 'oanda', auto.assign = FALSE)

#- For economics series, the FRED source is used.
Japan_GDP <- getSymbols(Symbols = 'JPNNGDP', src = 'FRED', auto.assign = FALSE)

